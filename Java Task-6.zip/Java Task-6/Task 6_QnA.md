1. What is Swing?
Swing is a Java GUI toolkit used to create desktop applications. It’s built on top of AWT but provides more advanced, lightweight, and platform-independent components like buttons, text fields, tables, and trees.


2. Difference between AWT and Swing
AWT (Abstract Window Toolkit) is Java’s original GUI library, using native system components.
Swing is built on top of AWT, is lightweight, and uses pure Java components (drawn by Java, not the OS).
Swing provides more flexible and richer UI components than AWT.


3. What is ActionListener?
ActionListener is an interface used in Java Swing to handle action events like button clicks.
You implement its actionPerformed(ActionEvent e) method to define what happens when the event occurs.


4. How to manage layouts in Java?
Java uses layout managers to control how components are arranged inside a container. Examples:
FlowLayout → Places components in a row.
BorderLayout → Divides into North, South, East, West, Center.
GridLayout → Arranges components in a grid of rows & columns.


5. What is the Event Dispatch Thread (EDT)?
EDT is the special thread in Java responsible for handling all GUI events (like button clicks, mouse movement, etc.) and updating the UI.
All GUI updates must be done on the EDT to avoid threading issues.


6. What are the GUI components in Java?
Common Swing components include:
JFrame (window)
JButton (button)
JTextField (input box)
JLabel (text label)
JList (list of items)
JTable (table display)
JScrollPane (scroll bar support)


7. How to handle multiple events?
Implement multiple listener interfaces in a single class.
Or use separate listener classes for each event type.
Or use anonymous inner classes or lambdas for concise code.


8. What is JPanel vs JFrame?
JFrame → The main window of a Swing application (top-level container).
JPanel → A lightweight container used to group and organize components inside a JFrame.


9. How to add scroll bar in GUI?
Use JScrollPane. Wrap your component inside it:
JScrollPane scrollPane = new JScrollPane(myComponent);
It automatically adds vertical and horizontal scrollbars when needed.


10. What is MVC architecture?
MVC stands for Model-View-Controller:
Model → Manages data and logic.
View → Handles the display (UI).
Controller → Handles user input and updates the model/view.
It’s used to separate logic from the UI, making code cleaner and easier to maintain.